# Master version for Pillow
__version__ = "8.0.1"
